import React from 'react';
import { Navigation, Clock, DollarSign, MapPin } from 'lucide-react';

export default function RiderDashboard() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Rider Dashboard</h1>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Navigation className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Active Deliveries</h2>
          <p className="text-3xl font-bold">3</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <Clock className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Today's Hours</h2>
          <p className="text-3xl font-bold">6.5</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <DollarSign className="h-8 w-8 text-green-600 mb-4" />
          <h2 className="text-lg font-semibold mb-2">Today's Earnings</h2>
          <p className="text-3xl font-bold">₹850</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Current Deliveries</h2>
          <div className="space-y-4">
            <div className="border-l-4 border-green-600 pl-4">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">Order #DEL001</span>
                <span className="text-green-600">₹120</span>
              </div>
              <p className="text-sm text-gray-600">Pickup: Fresh Farm Vegetables</p>
              <p className="text-sm text-gray-600">Delivery: 123 Main St</p>
              <div className="mt-2 flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span className="text-sm text-gray-600">2.5 km away</span>
              </div>
              <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Start Navigation
              </button>
            </div>
            <div className="border-l-4 border-yellow-600 pl-4">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">Order #DEL002</span>
                <span className="text-green-600">₹90</span>
              </div>
              <p className="text-sm text-gray-600">Pickup: Green Market</p>
              <p className="text-sm text-gray-600">Delivery: 456 Oak Ave</p>
              <div className="mt-2 flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span className="text-sm text-gray-600">1.8 km away</span>
              </div>
              <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                Start Navigation
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Delivery Statistics</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Deliveries Today</span>
              <span className="font-semibold">12</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Average Delivery Time</span>
              <span className="font-semibold">25 mins</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Customer Rating</span>
              <span className="font-semibold">4.8/5.0</span>
            </div>
            <div className="mt-4">
              <div className="bg-gray-200 h-2 rounded-full">
                <div className="bg-green-600 h-2 rounded-full w-3/4"></div>
              </div>
              <p className="text-sm text-gray-600 mt-2">Today's Goal Progress (75%)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}