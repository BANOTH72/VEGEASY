import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf, Home } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="bg-green-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2 hover:text-green-100 transition-colors">
            <Leaf className="h-8 w-8" />
            <span className="text-xl font-bold">VegEasy</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link to="/" className="flex items-center space-x-1 hover:bg-green-700 px-3 py-2 rounded-md">
              <Home className="h-5 w-5" />
              <span>Home</span>
            </Link>
            <Link to="/customer" className="hover:bg-green-700 px-3 py-2 rounded-md">
              Buy Vegetables
            </Link>
            <Link to="/vendor" className="hover:bg-green-700 px-3 py-2 rounded-md">
              Sell Vegetables
            </Link>
            <Link to="/rider" className="hover:bg-green-700 px-3 py-2 rounded-md">
              Become a Rider
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}